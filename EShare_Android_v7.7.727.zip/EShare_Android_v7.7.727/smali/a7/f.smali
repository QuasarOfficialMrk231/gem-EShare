.class public final La7/f;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ly6/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        La7/f$a;
    }
.end annotation


# static fields
.field private static final f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lokhttp3/t$a;

.field final b:Lx6/g;

.field private final c:La7/g;

.field private d:La7/i;

.field private final e:Lokhttp3/x;


# direct methods
.method static constructor <clinit>()V
    .locals 12

    const-string v0, "connection"

    const-string v1, "host"

    const-string v2, "keep-alive"

    const-string v3, "proxy-connection"

    const-string v4, "te"

    const-string v5, "transfer-encoding"

    const-string v6, "encoding"

    const-string v7, "upgrade"

    const-string v8, ":method"

    const-string v9, ":path"

    const-string v10, ":scheme"

    const-string v11, ":authority"

    filled-new-array/range {v0 .. v11}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lv6/c;->u([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, La7/f;->f:Ljava/util/List;

    const-string v1, "connection"

    const-string v2, "host"

    const-string v3, "keep-alive"

    const-string v4, "proxy-connection"

    const-string v5, "te"

    const-string v6, "transfer-encoding"

    const-string v7, "encoding"

    const-string v8, "upgrade"

    filled-new-array/range {v1 .. v8}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lv6/c;->u([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, La7/f;->g:Ljava/util/List;

    return-void
.end method

.method public constructor <init>(Lokhttp3/w;Lokhttp3/t$a;Lx6/g;La7/g;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, La7/f;->a:Lokhttp3/t$a;

    iput-object p3, p0, La7/f;->b:Lx6/g;

    iput-object p4, p0, La7/f;->c:La7/g;

    invoke-virtual {p1}, Lokhttp3/w;->y()Ljava/util/List;

    move-result-object p1

    sget-object p2, Lokhttp3/x;->f:Lokhttp3/x;

    invoke-interface {p1, p2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    sget-object p2, Lokhttp3/x;->e:Lokhttp3/x;

    :goto_0
    iput-object p2, p0, La7/f;->e:Lokhttp3/x;

    return-void
.end method

.method public static g(Lokhttp3/z;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lokhttp3/z;",
            ")",
            "Ljava/util/List<",
            "La7/c;",
            ">;"
        }
    .end annotation

    invoke-virtual {p0}, Lokhttp3/z;->d()Lokhttp3/r;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-virtual {v0}, Lokhttp3/r;->h()I

    move-result v2

    add-int/lit8 v2, v2, 0x4

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    new-instance v2, La7/c;

    sget-object v3, La7/c;->f:Le7/f;

    invoke-virtual {p0}, Lokhttp3/z;->f()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v3, v4}, La7/c;-><init>(Le7/f;Ljava/lang/String;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    new-instance v2, La7/c;

    sget-object v3, La7/c;->g:Le7/f;

    invoke-virtual {p0}, Lokhttp3/z;->h()Lokhttp3/s;

    move-result-object v4

    invoke-static {v4}, Ly6/i;->c(Lokhttp3/s;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v3, v4}, La7/c;-><init>(Le7/f;Ljava/lang/String;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const-string v2, "Host"

    invoke-virtual {p0, v2}, Lokhttp3/z;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_0

    new-instance v3, La7/c;

    sget-object v4, La7/c;->i:Le7/f;

    invoke-direct {v3, v4, v2}, La7/c;-><init>(Le7/f;Ljava/lang/String;)V

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    new-instance v2, La7/c;

    sget-object v3, La7/c;->h:Le7/f;

    invoke-virtual {p0}, Lokhttp3/z;->h()Lokhttp3/s;

    move-result-object p0

    invoke-virtual {p0}, Lokhttp3/s;->D()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v2, v3, p0}, La7/c;-><init>(Le7/f;Ljava/lang/String;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Lokhttp3/r;->h()I

    move-result p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, p0, :cond_2

    invoke-virtual {v0, v2}, Lokhttp3/r;->e(I)Ljava/lang/String;

    move-result-object v3

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v3, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Le7/f;->i(Ljava/lang/String;)Le7/f;

    move-result-object v3

    sget-object v4, La7/f;->f:Ljava/util/List;

    invoke-virtual {v3}, Le7/f;->I()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_1

    new-instance v4, La7/c;

    invoke-virtual {v0, v2}, Lokhttp3/r;->i(I)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v3, v5}, La7/c;-><init>(Le7/f;Ljava/lang/String;)V

    invoke-interface {v1, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    return-object v1
.end method

.method public static h(Lokhttp3/r;Lokhttp3/x;)Lokhttp3/b0$a;
    .locals 7

    new-instance v0, Lokhttp3/r$a;

    invoke-direct {v0}, Lokhttp3/r$a;-><init>()V

    invoke-virtual {p0}, Lokhttp3/r;->h()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_2

    invoke-virtual {p0, v3}, Lokhttp3/r;->e(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p0, v3}, Lokhttp3/r;->i(I)Ljava/lang/String;

    move-result-object v5

    const-string v6, ":status"

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "HTTP/1.1 "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ly6/k;->a(Ljava/lang/String;)Ly6/k;

    move-result-object v2

    goto :goto_1

    :cond_0
    sget-object v6, La7/f;->g:Ljava/util/List;

    invoke-interface {v6, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1

    sget-object v6, Lv6/a;->a:Lv6/a;

    invoke-virtual {v6, v0, v4, v5}, Lv6/a;->b(Lokhttp3/r$a;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    if-eqz v2, :cond_3

    new-instance p0, Lokhttp3/b0$a;

    invoke-direct {p0}, Lokhttp3/b0$a;-><init>()V

    invoke-virtual {p0, p1}, Lokhttp3/b0$a;->n(Lokhttp3/x;)Lokhttp3/b0$a;

    move-result-object p0

    iget p1, v2, Ly6/k;->b:I

    invoke-virtual {p0, p1}, Lokhttp3/b0$a;->g(I)Lokhttp3/b0$a;

    move-result-object p0

    iget-object p1, v2, Ly6/k;->c:Ljava/lang/String;

    invoke-virtual {p0, p1}, Lokhttp3/b0$a;->k(Ljava/lang/String;)Lokhttp3/b0$a;

    move-result-object p0

    invoke-virtual {v0}, Lokhttp3/r$a;->d()Lokhttp3/r;

    move-result-object p1

    invoke-virtual {p0, p1}, Lokhttp3/b0$a;->j(Lokhttp3/r;)Lokhttp3/b0$a;

    move-result-object p0

    return-object p0

    :cond_3
    new-instance p0, Ljava/net/ProtocolException;

    const-string p1, "Expected \':status\' header not present"

    invoke-direct {p0, p1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public a()V
    .locals 1

    iget-object v0, p0, La7/f;->d:La7/i;

    invoke-virtual {v0}, La7/i;->j()Le7/s;

    move-result-object v0

    invoke-interface {v0}, Le7/s;->close()V

    return-void
.end method

.method public b(Lokhttp3/z;)V
    .locals 3

    iget-object v0, p0, La7/f;->d:La7/i;

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p1}, Lokhttp3/z;->a()Lokhttp3/a0;

    move-result-object v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    invoke-static {p1}, La7/f;->g(Lokhttp3/z;)Ljava/util/List;

    move-result-object p1

    iget-object v1, p0, La7/f;->c:La7/g;

    invoke-virtual {v1, p1, v0}, La7/g;->f0(Ljava/util/List;Z)La7/i;

    move-result-object p1

    iput-object p1, p0, La7/f;->d:La7/i;

    invoke-virtual {p1}, La7/i;->n()Le7/u;

    move-result-object p1

    iget-object v0, p0, La7/f;->a:Lokhttp3/t$a;

    invoke-interface {v0}, Lokhttp3/t$a;->b()I

    move-result v0

    int-to-long v0, v0

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {p1, v0, v1, v2}, Le7/u;->g(JLjava/util/concurrent/TimeUnit;)Le7/u;

    iget-object p1, p0, La7/f;->d:La7/i;

    invoke-virtual {p1}, La7/i;->u()Le7/u;

    move-result-object p1

    iget-object v0, p0, La7/f;->a:Lokhttp3/t$a;

    invoke-interface {v0}, Lokhttp3/t$a;->c()I

    move-result v0

    int-to-long v0, v0

    invoke-virtual {p1, v0, v1, v2}, Le7/u;->g(JLjava/util/concurrent/TimeUnit;)Le7/u;

    return-void
.end method

.method public c(Lokhttp3/b0;)Lokhttp3/c0;
    .locals 4

    iget-object v0, p0, La7/f;->b:Lx6/g;

    iget-object v1, v0, Lx6/g;->f:Lokhttp3/o;

    iget-object v0, v0, Lx6/g;->e:Lokhttp3/d;

    invoke-virtual {v1, v0}, Lokhttp3/o;->q(Lokhttp3/d;)V

    const-string v0, "Content-Type"

    invoke-virtual {p1, v0}, Lokhttp3/b0;->E(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {p1}, Ly6/e;->b(Lokhttp3/b0;)J

    move-result-wide v1

    new-instance p1, La7/f$a;

    iget-object v3, p0, La7/f;->d:La7/i;

    invoke-virtual {v3}, La7/i;->k()Le7/t;

    move-result-object v3

    invoke-direct {p1, p0, v3}, La7/f$a;-><init>(La7/f;Le7/t;)V

    new-instance v3, Ly6/h;

    invoke-static {p1}, Le7/l;->b(Le7/t;)Le7/e;

    move-result-object p1

    invoke-direct {v3, v0, v1, v2, p1}, Ly6/h;-><init>(Ljava/lang/String;JLe7/e;)V

    return-object v3
.end method

.method public cancel()V
    .locals 2

    iget-object v0, p0, La7/f;->d:La7/i;

    if-eqz v0, :cond_0

    sget-object v1, La7/b;->g:La7/b;

    invoke-virtual {v0, v1}, La7/i;->h(La7/b;)V

    :cond_0
    return-void
.end method

.method public d()V
    .locals 1

    iget-object v0, p0, La7/f;->c:La7/g;

    invoke-virtual {v0}, La7/g;->flush()V

    return-void
.end method

.method public e(Lokhttp3/z;J)Le7/s;
    .locals 0

    iget-object p1, p0, La7/f;->d:La7/i;

    invoke-virtual {p1}, La7/i;->j()Le7/s;

    move-result-object p1

    return-object p1
.end method

.method public f(Z)Lokhttp3/b0$a;
    .locals 2

    iget-object v0, p0, La7/f;->d:La7/i;

    invoke-virtual {v0}, La7/i;->s()Lokhttp3/r;

    move-result-object v0

    iget-object v1, p0, La7/f;->e:Lokhttp3/x;

    invoke-static {v0, v1}, La7/f;->h(Lokhttp3/r;Lokhttp3/x;)Lokhttp3/b0$a;

    move-result-object v0

    if-eqz p1, :cond_0

    sget-object p1, Lv6/a;->a:Lv6/a;

    invoke-virtual {p1, v0}, Lv6/a;->d(Lokhttp3/b0$a;)I

    move-result p1

    const/16 v1, 0x64

    if-ne p1, v1, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    return-object v0
.end method
