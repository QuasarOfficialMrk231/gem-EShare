.class La7/g$h$a;
.super La7/g$h;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La7/g$h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 0

    invoke-direct {p0}, La7/g$h;-><init>()V

    return-void
.end method


# virtual methods
.method public b(La7/i;)V
    .locals 1

    sget-object v0, La7/b;->f:La7/b;

    invoke-virtual {p1, v0}, La7/i;->f(La7/b;)V

    return-void
.end method
