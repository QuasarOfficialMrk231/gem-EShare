.class public interface abstract La7/l;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:La7/l;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La7/l$a;

    invoke-direct {v0}, La7/l$a;-><init>()V

    sput-object v0, La7/l;->a:La7/l;

    return-void
.end method


# virtual methods
.method public abstract a(ILjava/util/List;)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "La7/c;",
            ">;)Z"
        }
    .end annotation
.end method

.method public abstract b(ILjava/util/List;Z)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "La7/c;",
            ">;Z)Z"
        }
    .end annotation
.end method

.method public abstract c(ILa7/b;)V
.end method

.method public abstract d(ILe7/e;IZ)Z
.end method
