.class La7/g$f;
.super Lv6/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La7/g;->k0(ILa7/b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:I

.field final synthetic c:La7/b;

.field final synthetic d:La7/g;


# direct methods
.method varargs constructor <init>(La7/g;Ljava/lang/String;[Ljava/lang/Object;ILa7/b;)V
    .locals 0

    iput-object p1, p0, La7/g$f;->d:La7/g;

    iput p4, p0, La7/g$f;->b:I

    iput-object p5, p0, La7/g$f;->c:La7/b;

    invoke-direct {p0, p2, p3}, Lv6/b;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public k()V
    .locals 3

    iget-object v0, p0, La7/g$f;->d:La7/g;

    iget-object v0, v0, La7/g;->j:La7/l;

    iget v1, p0, La7/g$f;->b:I

    iget-object v2, p0, La7/g$f;->c:La7/b;

    invoke-interface {v0, v1, v2}, La7/l;->c(ILa7/b;)V

    iget-object v0, p0, La7/g$f;->d:La7/g;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, La7/g$f;->d:La7/g;

    iget-object v1, v1, La7/g;->t:Ljava/util/Set;

    iget v2, p0, La7/g$f;->b:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method
