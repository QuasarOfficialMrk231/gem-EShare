.class public La7/g$g;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La7/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "g"
.end annotation


# instance fields
.field a:Ljava/net/Socket;

.field b:Ljava/lang/String;

.field c:Le7/e;

.field d:Le7/d;

.field e:La7/g$h;

.field f:La7/l;

.field g:Z

.field h:I


# direct methods
.method public constructor <init>(Z)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, La7/g$h;->a:La7/g$h;

    iput-object v0, p0, La7/g$g;->e:La7/g$h;

    sget-object v0, La7/l;->a:La7/l;

    iput-object v0, p0, La7/g$g;->f:La7/l;

    iput-boolean p1, p0, La7/g$g;->g:Z

    return-void
.end method


# virtual methods
.method public a()La7/g;
    .locals 1

    new-instance v0, La7/g;

    invoke-direct {v0, p0}, La7/g;-><init>(La7/g$g;)V

    return-object v0
.end method

.method public b(La7/g$h;)La7/g$g;
    .locals 0

    iput-object p1, p0, La7/g$g;->e:La7/g$h;

    return-object p0
.end method

.method public c(I)La7/g$g;
    .locals 0

    iput p1, p0, La7/g$g;->h:I

    return-object p0
.end method

.method public d(Ljava/net/Socket;Ljava/lang/String;Le7/e;Le7/d;)La7/g$g;
    .locals 0

    iput-object p1, p0, La7/g$g;->a:Ljava/net/Socket;

    iput-object p2, p0, La7/g$g;->b:Ljava/lang/String;

    iput-object p3, p0, La7/g$g;->c:Le7/e;

    iput-object p4, p0, La7/g$g;->d:Le7/d;

    return-object p0
.end method
