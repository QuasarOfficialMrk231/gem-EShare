.class public abstract La7/g$h;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La7/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "h"
.end annotation


# static fields
.field public static final a:La7/g$h;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, La7/g$h$a;

    invoke-direct {v0}, La7/g$h$a;-><init>()V

    sput-object v0, La7/g$h;->a:La7/g$h;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(La7/g;)V
    .locals 0

    return-void
.end method

.method public abstract b(La7/i;)V
.end method
