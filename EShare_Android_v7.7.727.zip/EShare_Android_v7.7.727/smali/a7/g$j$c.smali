.class La7/g$j$c;
.super Lv6/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La7/g$j;->l(La7/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:La7/m;

.field final synthetic c:La7/g$j;


# direct methods
.method varargs constructor <init>(La7/g$j;Ljava/lang/String;[Ljava/lang/Object;La7/m;)V
    .locals 0

    iput-object p1, p0, La7/g$j$c;->c:La7/g$j;

    iput-object p4, p0, La7/g$j$c;->b:La7/m;

    invoke-direct {p0, p2, p3}, Lv6/b;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public k()V
    .locals 2

    :try_start_0
    iget-object v0, p0, La7/g$j$c;->c:La7/g$j;

    iget-object v0, v0, La7/g$j;->c:La7/g;

    iget-object v0, v0, La7/g;->r:La7/j;

    iget-object v1, p0, La7/g$j$c;->b:La7/m;

    invoke-virtual {v0, v1}, La7/j;->j(La7/m;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    iget-object v0, p0, La7/g$j$c;->c:La7/g$j;

    iget-object v0, v0, La7/g$j;->c:La7/g;

    invoke-static {v0}, La7/g;->j(La7/g;)V

    :goto_0
    return-void
.end method
