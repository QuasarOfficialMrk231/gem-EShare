.class La7/g$j$b;
.super Lv6/b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La7/g$j;->c(ZLa7/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic b:La7/g$j;


# direct methods
.method varargs constructor <init>(La7/g$j;Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 0

    iput-object p1, p0, La7/g$j$b;->b:La7/g$j;

    invoke-direct {p0, p2, p3}, Lv6/b;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public k()V
    .locals 2

    iget-object v0, p0, La7/g$j$b;->b:La7/g$j;

    iget-object v0, v0, La7/g$j;->c:La7/g;

    iget-object v1, v0, La7/g;->b:La7/g$h;

    invoke-virtual {v1, v0}, La7/g$h;->a(La7/g;)V

    return-void
.end method
