.class public La3/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcom/ecloud/eshare/bean/AlbumItem;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/ecloud/eshare/bean/AlbumItem;Lcom/ecloud/eshare/bean/AlbumItem;)I
    .locals 1

    invoke-virtual {p1}, Lcom/ecloud/eshare/bean/AlbumItem;->isCamera()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p2}, Lcom/ecloud/eshare/bean/AlbumItem;->isCamera()Z

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, -0x1

    return p1

    :cond_0
    invoke-virtual {p1}, Lcom/ecloud/eshare/bean/AlbumItem;->isCamera()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-virtual {p2}, Lcom/ecloud/eshare/bean/AlbumItem;->isCamera()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    invoke-virtual {p1}, Lcom/ecloud/eshare/bean/FileItem;->getTitle()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2}, Lcom/ecloud/eshare/bean/FileItem;->getTitle()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, Lcom/ecloud/eshare/bean/AlbumItem;

    check-cast p2, Lcom/ecloud/eshare/bean/AlbumItem;

    invoke-virtual {p0, p1, p2}, La3/a;->a(Lcom/ecloud/eshare/bean/AlbumItem;Lcom/ecloud/eshare/bean/AlbumItem;)I

    move-result p1

    return p1
.end method
