.class La3/d$b;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = La3/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# static fields
.field private static a:La3/d;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, La3/d;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, La3/d;-><init>(La3/d$a;)V

    sput-object v0, La3/d$b;->a:La3/d;

    return-void
.end method

.method static synthetic a()La3/d;
    .locals 1

    sget-object v0, La3/d$b;->a:La3/d;

    return-object v0
.end method
