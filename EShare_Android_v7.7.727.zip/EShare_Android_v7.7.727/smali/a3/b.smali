.class public La3/b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcom/ecloud/eshare/bean/AudioItem;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/ecloud/eshare/bean/AudioItem;Lcom/ecloud/eshare/bean/AudioItem;)I
    .locals 4

    invoke-virtual {p1}, Lcom/ecloud/eshare/bean/AudioItem;->getLetter()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2}, Lcom/ecloud/eshare/bean/AudioItem;->getLetter()Ljava/lang/String;

    move-result-object v1

    const-string v2, "#"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_0

    const/4 p1, 0x1

    return p1

    :cond_0
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1

    const/4 p1, -0x1

    return p1

    :cond_1
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p1

    return p1

    :cond_2
    invoke-virtual {p1}, Lcom/ecloud/eshare/bean/FileItem;->getTitle()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2}, Lcom/ecloud/eshare/bean/FileItem;->getTitle()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, Lcom/ecloud/eshare/bean/AudioItem;

    check-cast p2, Lcom/ecloud/eshare/bean/AudioItem;

    invoke-virtual {p0, p1, p2}, La3/b;->a(Lcom/ecloud/eshare/bean/AudioItem;Lcom/ecloud/eshare/bean/AudioItem;)I

    move-result p1

    return p1
.end method
