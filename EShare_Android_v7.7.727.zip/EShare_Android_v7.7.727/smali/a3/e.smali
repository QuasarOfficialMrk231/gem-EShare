.class public La3/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcom/ecloud/eshare/bean/FileItem;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/ecloud/eshare/bean/FileItem;Lcom/ecloud/eshare/bean/FileItem;)I
    .locals 5

    invoke-virtual {p1}, Lcom/ecloud/eshare/bean/FileItem;->getLastModified()J

    move-result-wide v0

    invoke-virtual {p2}, Lcom/ecloud/eshare/bean/FileItem;->getLastModified()J

    move-result-wide v2

    cmp-long v4, v0, v2

    if-lez v4, :cond_0

    const/4 p1, -0x1

    return p1

    :cond_0
    if-gez v4, :cond_1

    const/4 p1, 0x1

    return p1

    :cond_1
    invoke-virtual {p1}, Lcom/ecloud/eshare/bean/FileItem;->getTitle()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2}, Lcom/ecloud/eshare/bean/FileItem;->getTitle()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p1

    return p1
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    check-cast p1, Lcom/ecloud/eshare/bean/FileItem;

    check-cast p2, Lcom/ecloud/eshare/bean/FileItem;

    invoke-virtual {p0, p1, p2}, La3/e;->a(Lcom/ecloud/eshare/bean/FileItem;Lcom/ecloud/eshare/bean/FileItem;)I

    move-result p1

    return p1
.end method
