.class public abstract La6/a;
.super Ljava/lang/Object;
.source "SourceFile"
