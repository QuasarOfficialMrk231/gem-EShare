.class public interface abstract La0/p;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/graphics/drawable/Drawable;)V
.end method

.method public abstract b()Landroid/graphics/drawable/Drawable;
.end method
